package com.haire.model

data class Jobs(
    val image: Int,
    val alamat: String,
    val pekerjaan: String,
    val provinsi: String
)
