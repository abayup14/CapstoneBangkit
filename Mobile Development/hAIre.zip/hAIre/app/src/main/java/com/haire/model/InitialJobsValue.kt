package com.haire.model

import com.haire.R

object InitialJobsValue {
    val dummyJobs = listOf(
        Jobs(R.drawable.logo, "Kotabaru, South Kalimantan", "MINING DATA ENGINEER & ANALYST", "Kalimantan"),
        Jobs(R.drawable.jobs2, "Jakarta", "Cyber Security", "Jakarta"),
        Jobs(R.drawable.jobs1, "Kotabaru, South Kalimantan", "Front End Developer", "Kalimantan"),
        Jobs(R.drawable.jobs3, "Surabaya, East Java, Indonesia", "AI-Augmented Software Developer", "Surabaya")
    )
}